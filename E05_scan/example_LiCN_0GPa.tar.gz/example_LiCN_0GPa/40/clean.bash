#!/bin/bash
for i in EA*;do rm -f $i/{CHG,CHGCAR,WAVECAR};done
du -sh EA*
