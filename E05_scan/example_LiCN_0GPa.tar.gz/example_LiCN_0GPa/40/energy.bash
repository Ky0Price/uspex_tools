#!/bin/bash
for i in EA*;do echo -e $i "," $(grep 'without' $i/OUTCAR | tail -n 1 | awk '{print $7}');done > Energy.csv

