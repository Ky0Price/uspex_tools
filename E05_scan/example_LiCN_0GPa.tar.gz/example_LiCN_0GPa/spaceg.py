import ase.io.vasp
import ase.spacegroup
import os
path='./selected/'
#sglist=[]
for root,dirs,files in os.walk(path):
    #print(root)
    #print(dirs)
    #print(files)
    sglist=[]
    for file in files:
        file='./selected/'+file
        #print(file)
        atom = ase.io.vasp.read_vasp(file)
        sg=ase.spacegroup.get_spacegroup(atom,symprec=0.001)
        sgd=sg.todict()
        sgd['name']=file
        sglist.append(sgd)
print(sglist)